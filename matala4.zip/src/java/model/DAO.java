/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author debo
 */
public class DAO {

    Connection cn;
 private static Pattern pattern;
    private static Matcher matcher;
    
    
    public DAO() throws ClassNotFoundException, SQLException {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        String url = "jdbc:derby://localhost:1527/ROOT";
        cn = DriverManager.getConnection(url, "root", "root");
    }

    public boolean verificateUser2(studentBean sb) throws SQLException {
        try { 
       
            Statement st = cn.createStatement();
            String sql = "SELECT * FROM ROOT.STUDENT";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String mail = rs.getString("MAIL");
                String id = rs.getString("ID");
               
                if (sb.getMail().equals(mail ) || sb.getId().equals(id)) {
                   
                    
                    return true;
                }
            }
           
            return false;
        } finally {
            cn.close();
        }
    }
     
    public boolean verificateUser(studentBean sb) throws SQLException {
        try {
               
            Statement st = cn.createStatement();

            String sql = "SELECT * FROM ROOT.STUDENT";
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {
                String mail = rs.getString("MAIL");
                String password = rs.getString("PASSWORD");
               
             
                if (sb.getMail().equals(mail )&& sb.getPassword().equals(password)) {
                    
                    return true;
                }
            }
            return false;
        } finally {
            cn.close();
        }
    }

    public boolean createUser(studentBean sb) throws SQLException {
        int statement = 0;
        try {
          
            Statement st = cn.createStatement();
            String sql = "INSERT INTO ROOT.STUDENT (ID, FIRSTNAME, LASTNAME, PASSWORD, MAIL) "
                    + "VALUES ('"+sb.getId()+"' , '"+sb.getFirstName()+"', '"+sb.getLastname()+"', '"+sb.getPassword()+"','"+ sb.getMail()+"')";
            
            statement = st.executeUpdate(sql);
           
        } catch (Throwable e) {
            e.printStackTrace();
        }
        cn.close();
        return statement == 1;
    }

    public boolean verificateBook(bookBean bb) throws SQLException {
        try {
            Statement st = cn.createStatement();
            String sql = "SELECT * FROM ROOT.BOOKS";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String isbn = rs.getString("ISBN");
               Boolean available = rs.getBoolean("AVAILABLE");
                if (bb.getIsbn().equals(isbn) && available == true ) {
                    return true;  
                }
            }
            return false;
        } finally {
            cn.close();
        }
    }
 public boolean verificateBook2(bookBean bb) throws SQLException {
        try {
            Statement st = cn.createStatement();
            String sql = "SELECT * FROM ROOT.BOOKS";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String isbn = rs.getString("ISBN");
            
                if (bb.getIsbn().equals(isbn) ) {
                    return true;  
                }
            }
            return false;
        } finally {
            cn.close();
        }
    }
    public boolean addBook(bookBean bb) throws SQLException {
        int statement = 0;
        try {
            Statement st = cn.createStatement();
            String sql = "INSERT INTO ROOT.BOOKS (ISBN, NAME, AUTHOR, CATEGORY, AVAILABLE) "
                    + "VALUES ('"+ bb.getIsbn() + "' , '" + bb.getName() + "','" + bb.getAuthor() + "','"
                    + bb.getCategory() + "','" + true +"')";
            statement = st.executeUpdate(sql);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        cn.close();
        return statement == 1;
    }

    public String getBookName(String isbn) throws SQLException{
      String name ="";  int statement1 = 0, statement2 = 0;
        try {
            Statement st = cn.createStatement();
          String sql = " SELECT * FROM ROOT.BOOKS WHERE ISBN = '"+ isbn +"' ";
          
          ResultSet rs = st.executeQuery(sql);
                     while (rs.next()) {

                
                 name = rs.getString("NAME");
                     }  
                    }catch (Throwable e) {
            e.printStackTrace();
        } finally {
            cn.close();
        }
        return name;
    }
    
    public boolean takeBook(bookBean bb, studentBean sb) throws SQLException {
        int statement1 = 0, statement2 = 0;
        try {
            Statement st = cn.createStatement();
            String sql = "INSERT INTO ROOT.LOAN (MAIL, ISBN, DATE, NAMEBOOK) "
                    + "VALUES ('" + sb.getMail() + "', '" + bb.getIsbn() + "' ,  CURRENT_DATE , '" + bb.getName() + "')";
            statement1 = st.executeUpdate(sql);


          
            sql = "UPDATE ROOT.BOOKS SET AVAILABLE = FALSE   WHERE ISBN ='"+ bb.getIsbn()+"'";
            statement2 = st.executeUpdate(sql);

            return statement1 == 1 && statement2 == 1 ;

        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            cn.close();
        }
        return false;
    }

    public boolean verificateReturn(bookBean bb, studentBean sb) throws SQLException {
        try {
            Statement st = cn.createStatement();
            String sql = "SELECT * FROM ROOT.LOAN";
            ResultSet rsLoan = st.executeQuery(sql);
            while (rsLoan.next()) {
                String isbnLoan = rsLoan.getString("ISBN");
                String mailLoan = rsLoan.getString("MAIL");
                if (bb.getIsbn().equals(isbnLoan) && mailLoan.equals( sb.getMail()) ) {
                    return true;
                }
            }
            return false;
        } finally {
            cn.close();
        }
    }

    public Boolean returnBook(String [] allIsbn , studentBean sb) throws SQLException {
        int statement1 = 0, statement3 = 0;
                // statement2 = 0 
      
                for (String isbn : allIsbn){
                try {
            Statement st = cn.createStatement();
            String sql = "SELECT * FROM ROOT.LOAN";
            ResultSet rsLoan = st.executeQuery(sql);
            while (rsLoan.next()) {
               String isbnLoan = rsLoan.getString("ISBN");
                String mailLoan = rsLoan.getString("MAIL");
                if (isbn.equals(isbnLoan) && mailLoan.equals(sb.getMail())) {
                   
                    sql = "DELETE FROM ROOT.LOAN WHERE MAIL = '"+ sb.getMail() + "'AND ISBN ='"+ isbn +"'";
                    statement1 = st.executeUpdate(sql);
                    break;
                }
            }


            sql = "SELECT * FROM ROOT.BOOKS";
            ResultSet rsBook = st.executeQuery(sql);
            while (rsBook.next()) {
                String isbnBook = rsBook.getString("ISBN");
                if (isbn.equals(isbnBook)) {
                    
                   
                    sql = " UPDATE ROOT.BOOKS SET AVAILABLE = TRUE WHERE ISBN = '" + isbn +"' ";
                    statement3 = st.executeUpdate(sql);
                    break;
                }
            }
         
        } finally {
            cn.close();
        }}
      return true;
    
    }
    
    public Boolean verificateSearch(String name , String search){
        
        pattern = Pattern.compile(search);
         matcher = pattern.matcher(name);
     while(matcher.find()) {
           return true;
           
        }
    
    return false;
    }
    
}
