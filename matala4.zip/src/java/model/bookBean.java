/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author debo
 */
public class bookBean {

    protected String category;
    protected String isbn;
    protected String name;
    protected String author;
 
   Date d1;
   Date d2;
    protected  boolean available;
   
    protected ArrayList<studentBean> listStudent = new ArrayList<studentBean>();

    public bookBean(){
        
    }

    public bookBean(String n, String a, String c, String i) {
        category = c;
        isbn = i;
        name = n;
        author = a;
        available=true;
       // numCopies = num;
        //numCopiesAvaible = num;

    }

public boolean  getAvailable(){
    return available;
}
public void setAvailable(boolean flag){
    available=flag;
    
}
    public String getIsbn() {
        return isbn;
    }

   public void setIsbn(String isbn){
       this.isbn=isbn;
       
   }
public String getName(){
    
    return name;
}
 public void setName(String name){
       this.name=name;
       
   }
public String getAuthor(){
    
    return author;
}
public void setAuthor(String author){
    
    this.author=author;
}
    public String getCategory() {

        return category;
    }
    public void setCategory(String category){
    
    this.category=category;
}
    public ArrayList<studentBean> getList(){
        
        return listStudent;
    }

    public void showBook() {
        System.out.println("name:"+ name + "\n" + "author: " + author + "\n" + "isbn: " + isbn + "\n" + "category: " + category
                + "\n"+"Available: "+available +"\n");
                //+ "num of copies: " + numCopies + "\n" + "num of copies avaible: " + numCopiesAvaible +"\n");

    }

   

    public void showStudent2() {

        for (studentBean student : listStudent) {
            student.showStudent();
        }

    }
}
