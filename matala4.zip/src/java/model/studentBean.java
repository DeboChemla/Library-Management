/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author debo
 */
public class studentBean {

    protected String firstName,lastName,password , mail, gender , birth ;
   protected String id;

    protected Date date; 
    protected int numOfBook;
    protected double dayDelay=0; 
  protected DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    protected ArrayList<bookBean> listBooksOfStudent = new ArrayList<bookBean>();

   public studentBean(){
   }
   
public studentBean(String n, String ln, String id, String m, String pw, String g
        ,String d
        ) {
        firstName = n;
        lastName = ln;
        this.id = id;
        mail = m;
        password=pw;
        gender=g;
        birth= d;
        numOfBook = 0;

    }

    

    public String getId() {
        return this.id;
    }
    public String getGender(){
     return this.gender;   
    }

    public ArrayList<bookBean> getListBook() {

        return listBooksOfStudent;
    }

    public ArrayList<bookBean> getList() {
        return listBooksOfStudent;
    }

    public void showStudent() {

        System.out.println("name: " + firstName + "\n" + "familyname: " + lastName + "\n" + "ID: " + id + "\n" + "mail: " + mail + "\n");

    }

  


  public String getFirstName() {
        return firstName;
    }

    public void setFirstname(String firstname) {
        this.firstName = firstname;
    }

    public String getLastname() {
        return lastName;
    }

    public void setLastname(String lastname) {
        this.lastName = lastname;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirth() {
        return birth = sdf.format(date);
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

 
    public void setId(String id) {
        this.id = id;
    }


}
